<?php

$host="localhost"; // Host name
$username="bangaliy_anacms"; // Mysql username
$password="-{;aOH5D}h[3"; // Mysql password
$db_name="bangaliy_cms"; // Database name


// Connect to server and select databse.
$con = mysqli_connect("$host", "$username", "$password");
mysqli_select_db($con,"$db_name")or die("cannot select DB");
?>