<?php
    include 'Model/connect_db.php';
    require('pdf/fpdf.php');
    
    $OrderCode = $_POST["txtOrderCOde"];
    
    //get invoices data
    $query = mysqli_query($con,"SELECT o.CustomerId, o.ShippingAddress, o.PaymentMethod, o.AlternativeNumber, o.Amount, o.date, o.Status, c.Name, c.Gender, c.Email, 
    c.Phone, c.UserName, c.Password, c.District, c.Zip, c.Country, c.ShippingAddress FROM tblorder o INNER JOIN user c ON o.CustomerId=c.Id WHERE o.ordercode='$OrderCode'");
    $invoice = mysqli_fetch_array($query);
    
    //A4 width : 219mm
    //default margin : 10mm each side
    //writable horizontal : 219-(10*2)=189mm
    
    $pdf = new FPDF('P','mm','A4');
        
    $pdf->SetTopMargin(35);
    
    $pdf->AddPage();
    
    //set font to arial, bold, 14pt
    $pdf->SetFont('Arial','B',14);
    
    //Cell(width , height , text , border , end line , [align] )
    
    $pdf->Cell(130	,5,'Bangaliyana.com.bd',0,0);
    $pdf->Cell(59	,5,'INVOICE',0,1);//end of line
    
    //set font to arial, regular, 12pt
    $pdf->SetFont('Arial','',12);
    
    $pdf->Cell(130	,5,'Zohra Villa, 151/2, Jonaki Rd',0,0);
    $pdf->Cell(59	,5,'',0,1);//end of line
    
    $pdf->Cell(130	,5,'Ahmednagar, Mirpur-1, Dhaka 1216',0,0);
    $pdf->Cell(25	,5,'Date',0,0);
    $pdf->Cell(34	,5,$invoice['date'],0,1);//end of line
    
    $pdf->Cell(130	,5,'Phone [+88 0966 99 66 888]',0,0);
    $pdf->Cell(25	,5,'Invoice #',0,0);
    $pdf->Cell(34	,5,$OrderCode,0,1);//end of line
    
    $pdf->Cell(130	,5,'Email [support@bangaliyana.com.bd]',0,0);
    $pdf->Cell(25	,5,'Customer Id',0,0);
    $pdf->Cell(34	,5,$invoice['CustomerId'],0,1);//end of line
    
    //make a dummy empty cell as a vertical spacer
    $pdf->Cell(189	,10,'',0,1);//end of line
    
    //billing address
    $pdf->Cell(100	,5,'Bill to',0,1);//end of line
    
    //add dummy cell at beginning of each line for indentation
    $pdf->Cell(10	,5,'',0,0);
    $pdf->Cell(90	,5,$invoice['Name'],0,1);
    
    $pdf->Cell(10	,5,'',0,0);
    $pdf->Cell(90	,5,$invoice['Email'],0,1);
    
    $pdf->Cell(10	,5,'',0,0);
    $pdf->Cell(90	,5,$invoice['ShippingAddress'],0,1);
    
    $pdf->Cell(10	,5,'',0,0);
    $pdf->Cell(90	,5,$invoice['Phone'],0,1);
    
    //make a dummy empty cell as a vertical spacer
    $pdf->Cell(189	,10,'',0,1);//end of line
    
    //invoice contents
    $pdf->SetFont('Arial','B',12);
    
    $pdf->Cell(100	,5,'Description',1,0);
    $pdf->Cell(15	,5,'Qty',1,0);
    $pdf->Cell(15	,5,'Price',1,0);
    $pdf->Cell(25	,5,'Discount',1,0);
    $pdf->Cell(34	,5,'Amount',1,1);//end of line
    
    $pdf->SetFont('Arial','',10);
    
    //Numbers are right-aligned so we give 'R' after new line parameter
    
    //items
    $query = mysqli_query($con,"SELECT d.ProductID, d.Merchant, d.UnitPrice, d.Quantity, d.Discount, p.ProductName FROM tblorderdetails d 
    INNER JOIN tblproducts p ON d.ProductId=p.ProductID WHERE OrderID='$OrderCode'");
    $discount = 0; //total tax
    $amount = 0; //total amount
    
    //display the items
    while($item = mysqli_fetch_array($query)){
    	$pdf->Cell(100	,7,$item['ProductName'],1,0);
    	//add thousand separator using number_format function
    	$pdf->Cell(15	,7,$item['Quantity'],1,0);
    	$pdf->Cell(15	,7,$item['UnitPrice'],1,0);
    	$pdf->Cell(25	,7,number_format($item['Discount']),1,0);
    	$pdf->Cell(34	,7,number_format($item['UnitPrice']*$item['Quantity']-$item['Discount']),1,1,'R');//end of line
    	//accumulate tax and amount
    	$discount += $item['Discount'];
    	$amount += $item['UnitPrice']*$item['Quantity'];
    }
    
    //summary
    $pdf->Cell(130	,5,'',0,0);
    $pdf->Cell(25	,5,'Subtotal',0,0);
    $pdf->Cell(8	,5,'Tk.',1,0);
    $pdf->Cell(26	,5,number_format($amount),1,1,'R');//end of line
    
    $pdf->Cell(130	,5,'',0,0);
    $pdf->Cell(25	,5,'Discount',0,0);
    $pdf->Cell(8	,5,'Tk',1,0);
    $pdf->Cell(26	,5,number_format($discount),1,1,'R');//end of line
    
    //$pdf->Cell(130	,5,'',0,0);
    //$pdf->Cell(25	,5,'Tax Rate',0,0);
    //$pdf->Cell(4	,5,'Tk.',1,0);
    //$pdf->Cell(30	,5,'10%',1,1,'R');//end of line
    
    $pdf->Cell(130	,5,'',0,0);
    $pdf->Cell(25	,5,'Total Due',0,0);
    $pdf->Cell(8	,5,'Tk.',1,0);
    $pdf->Cell(26	,5,number_format($amount - $discount),1,1,'R');//end of line
    
    $pdf->Cell(130	,10,'______________________',0,1,'L');//end of line
    
    $pdf->Cell(130	,5,'Manager',0,1,'L');//end of line
    
    $pdf->Output();
//end pdf
?>
